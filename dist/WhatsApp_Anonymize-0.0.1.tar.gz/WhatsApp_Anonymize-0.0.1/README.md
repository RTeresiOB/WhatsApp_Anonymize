# WhatsApp_Anonymize
Repository offers researchers simple way to receive anonymized WhatsApp message history data from research subjects. Repository sets up python environment and runs code that formats WhatsApp messages into a .csv file, encrypts the identities of senders and creates aliases, and replaces references to human entities within the texts with a de-identified holder value. 
